-To start a local server double click the "startserver.bat".
 If you don't the .js files wont work.

7:34 PM 5/16/2024